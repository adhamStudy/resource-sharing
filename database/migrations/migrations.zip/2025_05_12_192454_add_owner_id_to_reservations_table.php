<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Step 1: Add the column as nullable
        Schema::table('reservations', function (Blueprint $table) {
            $table->foreignId('owner_id')
                  ->nullable() // allow null for now
                  ->after('id')
                  ->constrained('users')
                  ->onDelete('cascade');
        });

        // Step 2: Update existing records with a value (here, copy user_id)
        DB::table('reservations')->update([
            'owner_id' => DB::raw('user_id')
        ]);

        // Step 3: Make the column NOT NULL
        Schema::table('reservations', function (Blueprint $table) {
            $table->foreignId('owner_id')->nullable(false)->change();
        });
    }

    public function down(): void
    {
        Schema::table('reservations', function (Blueprint $table) {
            $table->dropForeign(['owner_id']);
            $table->dropColumn('owner_id');
        });
    }
};
